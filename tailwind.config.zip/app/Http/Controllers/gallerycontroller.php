<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\gallery;

class gallerycontroller extends Controller
{
     public function upload(Request $request){
        // dd($request->file('profile')->getRealPath());
        $gallery = $request->file('profile');
        $name= $gallery->getClientOriginalName();
        $gallery->storeAS('public/image',$name);
        $gallery_save = new gallery;
        // echo "hello bhao";
        $gallery_save->name =$name;
        $gallery_save->save();
        $photo = $request->profile;

        return back();

     }

    

    
}
