



<?php /**PATH C:\xampp\htdocs\folder\gallery\resources\views/dashboard.blade.php ENDPATH**/ ?>